<?php

/* layout.html.twig */
class __TwigTemplate_16283b047e51001fa551c6613f506d1938e559cb8b8d512c52666fb709a7f757 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "layout.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'bodyclass' => array($this, 'block_bodyclass'),
            'body' => array($this, 'block_body'),
            'container' => array($this, 'block_container'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1edcf04b0e0558de862e6882038088fb7f9256b5e28ba30898a48717c4d87f6f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1edcf04b0e0558de862e6882038088fb7f9256b5e28ba30898a48717c4d87f6f->enter($__internal_1edcf04b0e0558de862e6882038088fb7f9256b5e28ba30898a48717c4d87f6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        $__internal_30b1b8b74778fad81228174e2b902c2a184876af1a9010d497df99f97ac796b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_30b1b8b74778fad81228174e2b902c2a184876af1a9010d497df99f97ac796b9->enter($__internal_30b1b8b74778fad81228174e2b902c2a184876af1a9010d497df99f97ac796b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1edcf04b0e0558de862e6882038088fb7f9256b5e28ba30898a48717c4d87f6f->leave($__internal_1edcf04b0e0558de862e6882038088fb7f9256b5e28ba30898a48717c4d87f6f_prof);

        
        $__internal_30b1b8b74778fad81228174e2b902c2a184876af1a9010d497df99f97ac796b9->leave($__internal_30b1b8b74778fad81228174e2b902c2a184876af1a9010d497df99f97ac796b9_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_b681b8ca051fe9d7990a2143b521f2d33997af163a1392f828f9aba01d30a858 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b681b8ca051fe9d7990a2143b521f2d33997af163a1392f828f9aba01d30a858->enter($__internal_b681b8ca051fe9d7990a2143b521f2d33997af163a1392f828f9aba01d30a858_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_0fb7943da23463e5344f6454e02231ede1967815906f0a64ec1f5e067ce73563 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0fb7943da23463e5344f6454e02231ede1967815906f0a64ec1f5e067ce73563->enter($__internal_0fb7943da23463e5344f6454e02231ede1967815906f0a64ec1f5e067ce73563_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
";
        
        $__internal_0fb7943da23463e5344f6454e02231ede1967815906f0a64ec1f5e067ce73563->leave($__internal_0fb7943da23463e5344f6454e02231ede1967815906f0a64ec1f5e067ce73563_prof);

        
        $__internal_b681b8ca051fe9d7990a2143b521f2d33997af163a1392f828f9aba01d30a858->leave($__internal_b681b8ca051fe9d7990a2143b521f2d33997af163a1392f828f9aba01d30a858_prof);

    }

    // line 7
    public function block_bodyclass($context, array $blocks = array())
    {
        $__internal_e3e98207a13f064c2206486864a38c50e2f432594d2ce4d508e4522070691a11 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e3e98207a13f064c2206486864a38c50e2f432594d2ce4d508e4522070691a11->enter($__internal_e3e98207a13f064c2206486864a38c50e2f432594d2ce4d508e4522070691a11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyclass"));

        $__internal_3841c846ec291017452f35dec367315fcc8a05a0a46523cea075cd05f3cea8c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3841c846ec291017452f35dec367315fcc8a05a0a46523cea075cd05f3cea8c8->enter($__internal_3841c846ec291017452f35dec367315fcc8a05a0a46523cea075cd05f3cea8c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyclass"));

        
        $__internal_3841c846ec291017452f35dec367315fcc8a05a0a46523cea075cd05f3cea8c8->leave($__internal_3841c846ec291017452f35dec367315fcc8a05a0a46523cea075cd05f3cea8c8_prof);

        
        $__internal_e3e98207a13f064c2206486864a38c50e2f432594d2ce4d508e4522070691a11->leave($__internal_e3e98207a13f064c2206486864a38c50e2f432594d2ce4d508e4522070691a11_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_6073ff8bb07e1c2c80dcca5e415300e5e02148a41e26468e1e85556cdf4a0eaa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6073ff8bb07e1c2c80dcca5e415300e5e02148a41e26468e1e85556cdf4a0eaa->enter($__internal_6073ff8bb07e1c2c80dcca5e415300e5e02148a41e26468e1e85556cdf4a0eaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_69f66d425362d5e251a542949c8765bea67fdfd722acb94137511e44ccc6c00b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_69f66d425362d5e251a542949c8765bea67fdfd722acb94137511e44ccc6c00b->enter($__internal_69f66d425362d5e251a542949c8765bea67fdfd722acb94137511e44ccc6c00b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    <header class=\"main\">
        <h1>
            <a href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">
                <span></span>Une belle vie immobilière
            </a>
        </h1>
    </header>

    ";
        // line 18
        $this->displayBlock('container', $context, $blocks);
        
        $__internal_69f66d425362d5e251a542949c8765bea67fdfd722acb94137511e44ccc6c00b->leave($__internal_69f66d425362d5e251a542949c8765bea67fdfd722acb94137511e44ccc6c00b_prof);

        
        $__internal_6073ff8bb07e1c2c80dcca5e415300e5e02148a41e26468e1e85556cdf4a0eaa->leave($__internal_6073ff8bb07e1c2c80dcca5e415300e5e02148a41e26468e1e85556cdf4a0eaa_prof);

    }

    public function block_container($context, array $blocks = array())
    {
        $__internal_5bbe5199768228bd60f3ab2061cea96f26de788f1557df4b13f9c55d58ede8b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5bbe5199768228bd60f3ab2061cea96f26de788f1557df4b13f9c55d58ede8b7->enter($__internal_5bbe5199768228bd60f3ab2061cea96f26de788f1557df4b13f9c55d58ede8b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container"));

        $__internal_6c099d2f767c59357c0ab5d84b744e81effc24c2eea9ccce61cf33d5bc6772eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c099d2f767c59357c0ab5d84b744e81effc24c2eea9ccce61cf33d5bc6772eb->enter($__internal_6c099d2f767c59357c0ab5d84b744e81effc24c2eea9ccce61cf33d5bc6772eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container"));

        
        $__internal_6c099d2f767c59357c0ab5d84b744e81effc24c2eea9ccce61cf33d5bc6772eb->leave($__internal_6c099d2f767c59357c0ab5d84b744e81effc24c2eea9ccce61cf33d5bc6772eb_prof);

        
        $__internal_5bbe5199768228bd60f3ab2061cea96f26de788f1557df4b13f9c55d58ede8b7->leave($__internal_5bbe5199768228bd60f3ab2061cea96f26de788f1557df4b13f9c55d58ede8b7_prof);

    }

    // line 21
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_afad71a61170a0225988731d4665ee56cbeb72ef1bba7d141f95083d9144b786 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_afad71a61170a0225988731d4665ee56cbeb72ef1bba7d141f95083d9144b786->enter($__internal_afad71a61170a0225988731d4665ee56cbeb72ef1bba7d141f95083d9144b786_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_a64a4ad9c1b6a94be1763cbf636df31020aef0135d7430d1d0b47be0bc09e3d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a64a4ad9c1b6a94be1763cbf636df31020aef0135d7430d1d0b47be0bc09e3d9->enter($__internal_a64a4ad9c1b6a94be1763cbf636df31020aef0135d7430d1d0b47be0bc09e3d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 22
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/script.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_a64a4ad9c1b6a94be1763cbf636df31020aef0135d7430d1d0b47be0bc09e3d9->leave($__internal_a64a4ad9c1b6a94be1763cbf636df31020aef0135d7430d1d0b47be0bc09e3d9_prof);

        
        $__internal_afad71a61170a0225988731d4665ee56cbeb72ef1bba7d141f95083d9144b786->leave($__internal_afad71a61170a0225988731d4665ee56cbeb72ef1bba7d141f95083d9144b786_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 23,  140 => 22,  131 => 21,  105 => 18,  96 => 12,  92 => 10,  83 => 9,  66 => 7,  53 => 4,  44 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block stylesheets %}
    <link href=\"{{ asset('dist/style.css') }}\" rel=\"stylesheet\">
{% endblock %}

{% block bodyclass %}{% endblock %}

{% block body %}
    <header class=\"main\">
        <h1>
            <a href=\"{{ path('homepage') }}\">
                <span></span>Une belle vie immobilière
            </a>
        </h1>
    </header>

    {% block container %}{% endblock %}
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script src=\"{{ asset('dist/script.js') }}\"></script>
{% endblock %}", "layout.html.twig", "/Applications/MAMP/htdocs/licence-test/app/Resources/views/layout.html.twig");
    }
}
