<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_6bdc415026468751b0fd3b8ea4bb5b8b9e992dbfca85e1c86f20068b91fbe660 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b25405190301c5f9e279e7c469ace2477af3a6e1a0adba27bca7766f2838893f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b25405190301c5f9e279e7c469ace2477af3a6e1a0adba27bca7766f2838893f->enter($__internal_b25405190301c5f9e279e7c469ace2477af3a6e1a0adba27bca7766f2838893f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_8cc58b2ce7bec3970a791470056a29f0567471e03ac7856590efd317b7c8cacf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8cc58b2ce7bec3970a791470056a29f0567471e03ac7856590efd317b7c8cacf->enter($__internal_8cc58b2ce7bec3970a791470056a29f0567471e03ac7856590efd317b7c8cacf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b25405190301c5f9e279e7c469ace2477af3a6e1a0adba27bca7766f2838893f->leave($__internal_b25405190301c5f9e279e7c469ace2477af3a6e1a0adba27bca7766f2838893f_prof);

        
        $__internal_8cc58b2ce7bec3970a791470056a29f0567471e03ac7856590efd317b7c8cacf->leave($__internal_8cc58b2ce7bec3970a791470056a29f0567471e03ac7856590efd317b7c8cacf_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_c4c8ba0481ee9a52d9fca35d0cd4a8e016eb5b81976a167a9728344478d90b9b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c4c8ba0481ee9a52d9fca35d0cd4a8e016eb5b81976a167a9728344478d90b9b->enter($__internal_c4c8ba0481ee9a52d9fca35d0cd4a8e016eb5b81976a167a9728344478d90b9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_0a555fb7e55be1d50cfe0b2a628e35fef543a1d2235bca7cd1922ca8adafba32 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0a555fb7e55be1d50cfe0b2a628e35fef543a1d2235bca7cd1922ca8adafba32->enter($__internal_0a555fb7e55be1d50cfe0b2a628e35fef543a1d2235bca7cd1922ca8adafba32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_0a555fb7e55be1d50cfe0b2a628e35fef543a1d2235bca7cd1922ca8adafba32->leave($__internal_0a555fb7e55be1d50cfe0b2a628e35fef543a1d2235bca7cd1922ca8adafba32_prof);

        
        $__internal_c4c8ba0481ee9a52d9fca35d0cd4a8e016eb5b81976a167a9728344478d90b9b->leave($__internal_c4c8ba0481ee9a52d9fca35d0cd4a8e016eb5b81976a167a9728344478d90b9b_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_d2c87c9e1c16f6520859b47780adfe7ae6f12aac0cbe8d78da951d49d5810138 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d2c87c9e1c16f6520859b47780adfe7ae6f12aac0cbe8d78da951d49d5810138->enter($__internal_d2c87c9e1c16f6520859b47780adfe7ae6f12aac0cbe8d78da951d49d5810138_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_e0aa746b2f6a310a48f8c56599fc94868c21fb12264a0c5ad60b92f535bdf1a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e0aa746b2f6a310a48f8c56599fc94868c21fb12264a0c5ad60b92f535bdf1a8->enter($__internal_e0aa746b2f6a310a48f8c56599fc94868c21fb12264a0c5ad60b92f535bdf1a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_e0aa746b2f6a310a48f8c56599fc94868c21fb12264a0c5ad60b92f535bdf1a8->leave($__internal_e0aa746b2f6a310a48f8c56599fc94868c21fb12264a0c5ad60b92f535bdf1a8_prof);

        
        $__internal_d2c87c9e1c16f6520859b47780adfe7ae6f12aac0cbe8d78da951d49d5810138->leave($__internal_d2c87c9e1c16f6520859b47780adfe7ae6f12aac0cbe8d78da951d49d5810138_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_cfe60001aed3060dcb3062435985c8dd06b3bc1adfadf638669355aefdace99a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cfe60001aed3060dcb3062435985c8dd06b3bc1adfadf638669355aefdace99a->enter($__internal_cfe60001aed3060dcb3062435985c8dd06b3bc1adfadf638669355aefdace99a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_9dc17ea462919d01bae602fcd8b25c6209e3ec512a371b7350ef716c625bc8d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9dc17ea462919d01bae602fcd8b25c6209e3ec512a371b7350ef716c625bc8d3->enter($__internal_9dc17ea462919d01bae602fcd8b25c6209e3ec512a371b7350ef716c625bc8d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_9dc17ea462919d01bae602fcd8b25c6209e3ec512a371b7350ef716c625bc8d3->leave($__internal_9dc17ea462919d01bae602fcd8b25c6209e3ec512a371b7350ef716c625bc8d3_prof);

        
        $__internal_cfe60001aed3060dcb3062435985c8dd06b3bc1adfadf638669355aefdace99a->leave($__internal_cfe60001aed3060dcb3062435985c8dd06b3bc1adfadf638669355aefdace99a_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/Applications/MAMP/htdocs/licence-test/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
