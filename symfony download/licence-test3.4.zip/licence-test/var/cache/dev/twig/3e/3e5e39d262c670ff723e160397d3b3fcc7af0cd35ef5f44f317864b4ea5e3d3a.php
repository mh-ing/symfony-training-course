<?php

/* base.html.twig */
class __TwigTemplate_70f2ea4d9ba6befff2419e33e81e4263a6a39804101f8049eb9b3bfd1f26a548 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'bodyclass' => array($this, 'block_bodyclass'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c7161c0d9ec595683f7782c68ee9d203d729ed72f64054438cca0d71598127ec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c7161c0d9ec595683f7782c68ee9d203d729ed72f64054438cca0d71598127ec->enter($__internal_c7161c0d9ec595683f7782c68ee9d203d729ed72f64054438cca0d71598127ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_a57f03fdd73a2bddb5d90fa5bb3c183d1a72017ffe7d353445f1470f5bdbd75d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a57f03fdd73a2bddb5d90fa5bb3c183d1a72017ffe7d353445f1470f5bdbd75d->enter($__internal_a57f03fdd73a2bddb5d90fa5bb3c183d1a72017ffe7d353445f1470f5bdbd75d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body class=\"";
        // line 9
        $this->displayBlock('bodyclass', $context, $blocks);
        echo "\">
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 14
        echo "    </body>
</html>
";
        
        $__internal_c7161c0d9ec595683f7782c68ee9d203d729ed72f64054438cca0d71598127ec->leave($__internal_c7161c0d9ec595683f7782c68ee9d203d729ed72f64054438cca0d71598127ec_prof);

        
        $__internal_a57f03fdd73a2bddb5d90fa5bb3c183d1a72017ffe7d353445f1470f5bdbd75d->leave($__internal_a57f03fdd73a2bddb5d90fa5bb3c183d1a72017ffe7d353445f1470f5bdbd75d_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_0d1c476889506398979263618cf546c22d54b899c180e5d97468aa6d21e9b07d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0d1c476889506398979263618cf546c22d54b899c180e5d97468aa6d21e9b07d->enter($__internal_0d1c476889506398979263618cf546c22d54b899c180e5d97468aa6d21e9b07d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_09eacd36dd3a0f67a077fa98673e654a15ed5cc72821046a52c231556bdf9c60 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09eacd36dd3a0f67a077fa98673e654a15ed5cc72821046a52c231556bdf9c60->enter($__internal_09eacd36dd3a0f67a077fa98673e654a15ed5cc72821046a52c231556bdf9c60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_09eacd36dd3a0f67a077fa98673e654a15ed5cc72821046a52c231556bdf9c60->leave($__internal_09eacd36dd3a0f67a077fa98673e654a15ed5cc72821046a52c231556bdf9c60_prof);

        
        $__internal_0d1c476889506398979263618cf546c22d54b899c180e5d97468aa6d21e9b07d->leave($__internal_0d1c476889506398979263618cf546c22d54b899c180e5d97468aa6d21e9b07d_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_6cca8fbc6072bb05bc059674f95230eb33d6d7781b35a669a3a947bef8eb9c3a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6cca8fbc6072bb05bc059674f95230eb33d6d7781b35a669a3a947bef8eb9c3a->enter($__internal_6cca8fbc6072bb05bc059674f95230eb33d6d7781b35a669a3a947bef8eb9c3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_d338c9e28a5fa6bdc8ef5a67bdd778a0ba4cf70b490b463436b0ddc14c66f840 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d338c9e28a5fa6bdc8ef5a67bdd778a0ba4cf70b490b463436b0ddc14c66f840->enter($__internal_d338c9e28a5fa6bdc8ef5a67bdd778a0ba4cf70b490b463436b0ddc14c66f840_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_d338c9e28a5fa6bdc8ef5a67bdd778a0ba4cf70b490b463436b0ddc14c66f840->leave($__internal_d338c9e28a5fa6bdc8ef5a67bdd778a0ba4cf70b490b463436b0ddc14c66f840_prof);

        
        $__internal_6cca8fbc6072bb05bc059674f95230eb33d6d7781b35a669a3a947bef8eb9c3a->leave($__internal_6cca8fbc6072bb05bc059674f95230eb33d6d7781b35a669a3a947bef8eb9c3a_prof);

    }

    // line 9
    public function block_bodyclass($context, array $blocks = array())
    {
        $__internal_2fdb9b627c5392f9412caf6118365f07bdc756938a82540bf02911dab56b9078 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2fdb9b627c5392f9412caf6118365f07bdc756938a82540bf02911dab56b9078->enter($__internal_2fdb9b627c5392f9412caf6118365f07bdc756938a82540bf02911dab56b9078_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyclass"));

        $__internal_f31ec4429f55fb348f3f2ca9a7d98eded31137026344e1cfa002dd2a7b619d7d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f31ec4429f55fb348f3f2ca9a7d98eded31137026344e1cfa002dd2a7b619d7d->enter($__internal_f31ec4429f55fb348f3f2ca9a7d98eded31137026344e1cfa002dd2a7b619d7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyclass"));

        
        $__internal_f31ec4429f55fb348f3f2ca9a7d98eded31137026344e1cfa002dd2a7b619d7d->leave($__internal_f31ec4429f55fb348f3f2ca9a7d98eded31137026344e1cfa002dd2a7b619d7d_prof);

        
        $__internal_2fdb9b627c5392f9412caf6118365f07bdc756938a82540bf02911dab56b9078->leave($__internal_2fdb9b627c5392f9412caf6118365f07bdc756938a82540bf02911dab56b9078_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_c6a5c1834e28ef5349485a30a795a247a977963bac11718e2be9b21843792e90 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c6a5c1834e28ef5349485a30a795a247a977963bac11718e2be9b21843792e90->enter($__internal_c6a5c1834e28ef5349485a30a795a247a977963bac11718e2be9b21843792e90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e55d9d7d14f85f7421b83fafe7fc5840a55183b04b5882dc5c850bd0503154d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e55d9d7d14f85f7421b83fafe7fc5840a55183b04b5882dc5c850bd0503154d6->enter($__internal_e55d9d7d14f85f7421b83fafe7fc5840a55183b04b5882dc5c850bd0503154d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_e55d9d7d14f85f7421b83fafe7fc5840a55183b04b5882dc5c850bd0503154d6->leave($__internal_e55d9d7d14f85f7421b83fafe7fc5840a55183b04b5882dc5c850bd0503154d6_prof);

        
        $__internal_c6a5c1834e28ef5349485a30a795a247a977963bac11718e2be9b21843792e90->leave($__internal_c6a5c1834e28ef5349485a30a795a247a977963bac11718e2be9b21843792e90_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_335956bebf13240ed874d2eda7a3ed9fc6e1713da1f8d996a910714aac82dab6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_335956bebf13240ed874d2eda7a3ed9fc6e1713da1f8d996a910714aac82dab6->enter($__internal_335956bebf13240ed874d2eda7a3ed9fc6e1713da1f8d996a910714aac82dab6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_c31ec2abab9080b4bc7778f9a026f223f7b578a78364c6545f47cd91a382304a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c31ec2abab9080b4bc7778f9a026f223f7b578a78364c6545f47cd91a382304a->enter($__internal_c31ec2abab9080b4bc7778f9a026f223f7b578a78364c6545f47cd91a382304a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 12
        echo "            <script type=\"text/javascript\" src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        ";
        
        $__internal_c31ec2abab9080b4bc7778f9a026f223f7b578a78364c6545f47cd91a382304a->leave($__internal_c31ec2abab9080b4bc7778f9a026f223f7b578a78364c6545f47cd91a382304a_prof);

        
        $__internal_335956bebf13240ed874d2eda7a3ed9fc6e1713da1f8d996a910714aac82dab6->leave($__internal_335956bebf13240ed874d2eda7a3ed9fc6e1713da1f8d996a910714aac82dab6_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 12,  138 => 11,  121 => 10,  104 => 9,  87 => 6,  69 => 5,  57 => 14,  54 => 11,  52 => 10,  48 => 9,  42 => 7,  40 => 6,  36 => 5,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body class=\"{% block bodyclass %}{% endblock %}\">
        {% block body %}{% endblock %}
        {% block javascripts %}
            <script type=\"text/javascript\" src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        {% endblock %}
    </body>
</html>
", "base.html.twig", "/Applications/MAMP/htdocs/licence-test/app/Resources/views/base.html.twig");
    }
}
