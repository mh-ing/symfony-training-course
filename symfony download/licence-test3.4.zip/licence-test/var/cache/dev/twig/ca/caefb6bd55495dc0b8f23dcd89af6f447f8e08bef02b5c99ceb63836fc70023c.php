<?php

/* homepage/home.html.twig */
class __TwigTemplate_25ab2c2fbdd4c30d4d01bce1fab8e3fc5840ebc40c31fb7e3287be08d5845145 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "homepage/home.html.twig", 1);
        $this->blocks = array(
            'bodyclass' => array($this, 'block_bodyclass'),
            'container' => array($this, 'block_container'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_452e90da36001e54b01eb475de2cb3115e7f49cd6e751ac64b19dfb0b067e12d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_452e90da36001e54b01eb475de2cb3115e7f49cd6e751ac64b19dfb0b067e12d->enter($__internal_452e90da36001e54b01eb475de2cb3115e7f49cd6e751ac64b19dfb0b067e12d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "homepage/home.html.twig"));

        $__internal_18fac126a2c5d229227c98e8d839528aa1fc71fcb3d1e0e39e860d843a43973b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18fac126a2c5d229227c98e8d839528aa1fc71fcb3d1e0e39e860d843a43973b->enter($__internal_18fac126a2c5d229227c98e8d839528aa1fc71fcb3d1e0e39e860d843a43973b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "homepage/home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_452e90da36001e54b01eb475de2cb3115e7f49cd6e751ac64b19dfb0b067e12d->leave($__internal_452e90da36001e54b01eb475de2cb3115e7f49cd6e751ac64b19dfb0b067e12d_prof);

        
        $__internal_18fac126a2c5d229227c98e8d839528aa1fc71fcb3d1e0e39e860d843a43973b->leave($__internal_18fac126a2c5d229227c98e8d839528aa1fc71fcb3d1e0e39e860d843a43973b_prof);

    }

    // line 3
    public function block_bodyclass($context, array $blocks = array())
    {
        $__internal_e810094f7c4cea84b041523323d4ae494831a321fa2618a7f5cd8cc4ac71b95a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e810094f7c4cea84b041523323d4ae494831a321fa2618a7f5cd8cc4ac71b95a->enter($__internal_e810094f7c4cea84b041523323d4ae494831a321fa2618a7f5cd8cc4ac71b95a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyclass"));

        $__internal_75edd4fc7ebe58b054c6ecb95a46f7764fd61cc1699cfde2240f9d1a4de50662 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_75edd4fc7ebe58b054c6ecb95a46f7764fd61cc1699cfde2240f9d1a4de50662->enter($__internal_75edd4fc7ebe58b054c6ecb95a46f7764fd61cc1699cfde2240f9d1a4de50662_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyclass"));

        echo "form flex-container-v";
        
        $__internal_75edd4fc7ebe58b054c6ecb95a46f7764fd61cc1699cfde2240f9d1a4de50662->leave($__internal_75edd4fc7ebe58b054c6ecb95a46f7764fd61cc1699cfde2240f9d1a4de50662_prof);

        
        $__internal_e810094f7c4cea84b041523323d4ae494831a321fa2618a7f5cd8cc4ac71b95a->leave($__internal_e810094f7c4cea84b041523323d4ae494831a321fa2618a7f5cd8cc4ac71b95a_prof);

    }

    // line 5
    public function block_container($context, array $blocks = array())
    {
        $__internal_77467f5f1409aefe9cd5dbe42c34734e8640fd25d4d9ca99c18969c2342bcad0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_77467f5f1409aefe9cd5dbe42c34734e8640fd25d4d9ca99c18969c2342bcad0->enter($__internal_77467f5f1409aefe9cd5dbe42c34734e8640fd25d4d9ca99c18969c2342bcad0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container"));

        $__internal_a902e6565c468e0b37bd044718030a30d5685ff6fd81612b7f43fa815e4ff2c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a902e6565c468e0b37bd044718030a30d5685ff6fd81612b7f43fa815e4ff2c5->enter($__internal_a902e6565c468e0b37bd044718030a30d5685ff6fd81612b7f43fa815e4ff2c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "container"));

        // line 6
        echo "    <div id=\"container\" class=\"flex-container\">
        <div id=\"cover\">
            <div class=\"pin\">
                <img src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/img/pin-large-text.png"), "html", null, true);
        echo "\" alt=\"Les clefs de votre financement se trouvent ici\">
            </div>
            <div class=\"text txtcenter\">
                <em>Remplissez notre formulaire en ligne pour bénéficier de l’offre</em>
                <strong>Découvrez les programmes correspondant à votre projet d’achat dans le neuf</strong>
            </div>
        </div>

        <form name=\"appbundle_contact\" method=\"post\" id=\"form-contact\" autocomplete=\"off\" novalidate=\"novalidate\">
            <div class=\"grid-1-3\">
                <span class=\"txtright required\">Civilité</span>
                <div id=\"appbundle_contact_civility\" class=\"grid-3 radio\">
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_civility_0\" name=\"appbundle_contact[civility]\" required=\"required\" value=\"miss\">
                        <span>Mlle</span>
                    </label>
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_civility_1\" name=\"appbundle_contact[civility]\" required=\"required\" value=\"madam\">
                        <span>Mme</span>
                    </label>
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_civility_2\" name=\"appbundle_contact[civility]\" required=\"required\" value=\"mister\">
                        <span>M.</span>
                    </label>
                </div>
                <div class=\"error civility\"></div>
            </div>

            <div class=\"grid-1-3\">
                <label class=\"txtright required\" for=\"appbundle_contact_lastname\">Nom</label>
                <input type=\"text\" id=\"appbundle_contact_lastname\" name=\"appbundle_contact[lastname]\" required=\"required\" class=\"\">
                <div class=\"error lastname\">
                </div>
            </div>

            <div class=\"grid-1-3\">
                <label class=\"txtright required\" for=\"appbundle_contact_firstname\">Prénom</label>
                <input type=\"text\" id=\"appbundle_contact_firstname\" name=\"appbundle_contact[firstname]\" required=\"required\" class=\"\">
                <div class=\"error firstname\">
                </div>
            </div>

            <div class=\"grid-1-3\">
                <label class=\"txtright required\" for=\"appbundle_contact_postalCode\">Code postal</label>
                <input type=\"text\" id=\"appbundle_contact_postalCode\" name=\"appbundle_contact[postalCode]\" required=\"required\" class=\"\">
                <div class=\"error postalCode\">
                </div>
            </div>

            <div class=\"grid-1-3\">
                <label class=\"txtright required\" for=\"appbundle_contact_email\">Email</label>
                <input type=\"email\" id=\"appbundle_contact_email\" name=\"appbundle_contact[email]\" required=\"required\" class=\"\">
                <div class=\"error email\">
                </div>
            </div>

            <div class=\"grid-1-3\">
                <label class=\"txtright required\" for=\"appbundle_contact_phone\">Téléphone</label>
                <input type=\"text\" id=\"appbundle_contact_phone\" name=\"appbundle_contact[phone]\" required=\"required\" class=\"\">
                <div class=\"error phone\">
                </div>
            </div>

            <p>Souhaitez-vous recevoir l'actualité immobilière et les offres personnalisées de Nexity ?</p>
            <div class=\"grid-3-1 no-label\">
                <div id=\"appbundle_contact_hasNewsletter\" class=\"grid-2 radio\">
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_hasNewsletter_0\" name=\"appbundle_contact[hasNewsletter]\" required=\"required\"
                               value=\"1\">
                        <span>oui</span>
                    </label>
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_hasNewsletter_1\" name=\"appbundle_contact[hasNewsletter]\" required=\"required\"
                               value=\"0\">
                        <span>non</span>
                    </label>
                </div>
            </div>


            <p>Souhaitez-vous recevoir les offres de nos partenaires ?</p>
            <div class=\"grid-3-1 no-label\">
                <div id=\"appbundle_contact_hasPartnerOffer\" class=\"grid-2 radio\">
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_hasPartnerOffer_0\" name=\"appbundle_contact[hasPartnerOffer]\" required=\"required\"
                               value=\"1\">
                        <span>oui</span>
                    </label>
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_hasPartnerOffer_1\" name=\"appbundle_contact[hasPartnerOffer]\" required=\"required\"
                               value=\"0\">
                        <span>non</span>
                    </label>
                </div>
            </div>

            <p class=\"form-send-ok\">
                Votre demande a bien été transférée à nos services. Nous vous remercions de l'intérêt que vous nous portez.
            </p>

            <div class=\"txtcenter submit\">
                <input type=\"submit\" value=\"Valider\">
            </div>
        </form>
    </div>
";
        
        $__internal_a902e6565c468e0b37bd044718030a30d5685ff6fd81612b7f43fa815e4ff2c5->leave($__internal_a902e6565c468e0b37bd044718030a30d5685ff6fd81612b7f43fa815e4ff2c5_prof);

        
        $__internal_77467f5f1409aefe9cd5dbe42c34734e8640fd25d4d9ca99c18969c2342bcad0->leave($__internal_77467f5f1409aefe9cd5dbe42c34734e8640fd25d4d9ca99c18969c2342bcad0_prof);

    }

    // line 117
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_bc95aa2194eab8f3e2a7880aece2868c068190882e1a73a7ae81d1752696d9da = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bc95aa2194eab8f3e2a7880aece2868c068190882e1a73a7ae81d1752696d9da->enter($__internal_bc95aa2194eab8f3e2a7880aece2868c068190882e1a73a7ae81d1752696d9da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_2305ef230787bbf41b72f691cf3b6d6ce589d498fd4ad7952dcd4febf7ad60d7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2305ef230787bbf41b72f691cf3b6d6ce589d498fd4ad7952dcd4febf7ad60d7->enter($__internal_2305ef230787bbf41b72f691cf3b6d6ce589d498fd4ad7952dcd4febf7ad60d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 118
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 119
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/form-contact.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_2305ef230787bbf41b72f691cf3b6d6ce589d498fd4ad7952dcd4febf7ad60d7->leave($__internal_2305ef230787bbf41b72f691cf3b6d6ce589d498fd4ad7952dcd4febf7ad60d7_prof);

        
        $__internal_bc95aa2194eab8f3e2a7880aece2868c068190882e1a73a7ae81d1752696d9da->leave($__internal_bc95aa2194eab8f3e2a7880aece2868c068190882e1a73a7ae81d1752696d9da_prof);

    }

    public function getTemplateName()
    {
        return "homepage/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  204 => 119,  199 => 118,  190 => 117,  74 => 9,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block bodyclass %}form flex-container-v{% endblock %}

{% block container %}
    <div id=\"container\" class=\"flex-container\">
        <div id=\"cover\">
            <div class=\"pin\">
                <img src=\"{{ asset('dist/img/pin-large-text.png') }}\" alt=\"Les clefs de votre financement se trouvent ici\">
            </div>
            <div class=\"text txtcenter\">
                <em>Remplissez notre formulaire en ligne pour bénéficier de l’offre</em>
                <strong>Découvrez les programmes correspondant à votre projet d’achat dans le neuf</strong>
            </div>
        </div>

        <form name=\"appbundle_contact\" method=\"post\" id=\"form-contact\" autocomplete=\"off\" novalidate=\"novalidate\">
            <div class=\"grid-1-3\">
                <span class=\"txtright required\">Civilité</span>
                <div id=\"appbundle_contact_civility\" class=\"grid-3 radio\">
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_civility_0\" name=\"appbundle_contact[civility]\" required=\"required\" value=\"miss\">
                        <span>Mlle</span>
                    </label>
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_civility_1\" name=\"appbundle_contact[civility]\" required=\"required\" value=\"madam\">
                        <span>Mme</span>
                    </label>
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_civility_2\" name=\"appbundle_contact[civility]\" required=\"required\" value=\"mister\">
                        <span>M.</span>
                    </label>
                </div>
                <div class=\"error civility\"></div>
            </div>

            <div class=\"grid-1-3\">
                <label class=\"txtright required\" for=\"appbundle_contact_lastname\">Nom</label>
                <input type=\"text\" id=\"appbundle_contact_lastname\" name=\"appbundle_contact[lastname]\" required=\"required\" class=\"\">
                <div class=\"error lastname\">
                </div>
            </div>

            <div class=\"grid-1-3\">
                <label class=\"txtright required\" for=\"appbundle_contact_firstname\">Prénom</label>
                <input type=\"text\" id=\"appbundle_contact_firstname\" name=\"appbundle_contact[firstname]\" required=\"required\" class=\"\">
                <div class=\"error firstname\">
                </div>
            </div>

            <div class=\"grid-1-3\">
                <label class=\"txtright required\" for=\"appbundle_contact_postalCode\">Code postal</label>
                <input type=\"text\" id=\"appbundle_contact_postalCode\" name=\"appbundle_contact[postalCode]\" required=\"required\" class=\"\">
                <div class=\"error postalCode\">
                </div>
            </div>

            <div class=\"grid-1-3\">
                <label class=\"txtright required\" for=\"appbundle_contact_email\">Email</label>
                <input type=\"email\" id=\"appbundle_contact_email\" name=\"appbundle_contact[email]\" required=\"required\" class=\"\">
                <div class=\"error email\">
                </div>
            </div>

            <div class=\"grid-1-3\">
                <label class=\"txtright required\" for=\"appbundle_contact_phone\">Téléphone</label>
                <input type=\"text\" id=\"appbundle_contact_phone\" name=\"appbundle_contact[phone]\" required=\"required\" class=\"\">
                <div class=\"error phone\">
                </div>
            </div>

            <p>Souhaitez-vous recevoir l'actualité immobilière et les offres personnalisées de Nexity ?</p>
            <div class=\"grid-3-1 no-label\">
                <div id=\"appbundle_contact_hasNewsletter\" class=\"grid-2 radio\">
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_hasNewsletter_0\" name=\"appbundle_contact[hasNewsletter]\" required=\"required\"
                               value=\"1\">
                        <span>oui</span>
                    </label>
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_hasNewsletter_1\" name=\"appbundle_contact[hasNewsletter]\" required=\"required\"
                               value=\"0\">
                        <span>non</span>
                    </label>
                </div>
            </div>


            <p>Souhaitez-vous recevoir les offres de nos partenaires ?</p>
            <div class=\"grid-3-1 no-label\">
                <div id=\"appbundle_contact_hasPartnerOffer\" class=\"grid-2 radio\">
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_hasPartnerOffer_0\" name=\"appbundle_contact[hasPartnerOffer]\" required=\"required\"
                               value=\"1\">
                        <span>oui</span>
                    </label>
                    <label>
                        <input type=\"radio\" id=\"appbundle_contact_hasPartnerOffer_1\" name=\"appbundle_contact[hasPartnerOffer]\" required=\"required\"
                               value=\"0\">
                        <span>non</span>
                    </label>
                </div>
            </div>

            <p class=\"form-send-ok\">
                Votre demande a bien été transférée à nos services. Nous vous remercions de l'intérêt que vous nous portez.
            </p>

            <div class=\"txtcenter submit\">
                <input type=\"submit\" value=\"Valider\">
            </div>
        </form>
    </div>
{% endblock %}


{% block javascripts %}
    {{ parent() }}
    <script src=\"{{ asset('dist/form-contact.js') }}\"></script>
{% endblock %}", "homepage/home.html.twig", "/Applications/MAMP/htdocs/licence-test/app/Resources/views/homepage/home.html.twig");
    }
}
