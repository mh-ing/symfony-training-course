<?php

/* homepage/form.html.twig */
class __TwigTemplate_01986d91e87a0779881f9084f7502a2f3e9db27628e581b16a72a53f3423776a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0de23ec9fceac02b0ebc8bdd99d450c53c125be050bb83779b1d2e3af89e7782 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0de23ec9fceac02b0ebc8bdd99d450c53c125be050bb83779b1d2e3af89e7782->enter($__internal_0de23ec9fceac02b0ebc8bdd99d450c53c125be050bb83779b1d2e3af89e7782_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "homepage/form.html.twig"));

        $__internal_9248644a4782dd56dfe99125b96f2c890b5e81845fe94eb376e676c51de1d143 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9248644a4782dd56dfe99125b96f2c890b5e81845fe94eb376e676c51de1d143->enter($__internal_9248644a4782dd56dfe99125b96f2c890b5e81845fe94eb376e676c51de1d143_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "homepage/form.html.twig"));

        // line 1
        echo "<form name=\"appbundle_contact\" method=\"post\" id=\"form-contact\" autocomplete=\"off\" novalidate=\"novalidate\">

    <div class=\"grid-1-3\">
        <span class=\"txtright required\">Civilité</span>
        <div id=\"appbundle_contact_civility\" class=\"grid-3 radio\"><label>
                <input type=\"radio\" id=\"appbundle_contact_civility_0\" name=\"appbundle_contact[civility]\" required=\"required\" value=\"miss\">
                <span>Mlle</span>
            </label>        <label>
                <input type=\"radio\" id=\"appbundle_contact_civility_1\" name=\"appbundle_contact[civility]\" required=\"required\" value=\"madam\">
                <span>Mme</span>
            </label>        <label>
                <input type=\"radio\" id=\"appbundle_contact_civility_2\" name=\"appbundle_contact[civility]\" required=\"required\" value=\"mister\">
                <span>M.</span>
            </label>        </div>
        <div class=\"error civility\">

        </div>
    </div>

    <div class=\"grid-1-3\">
        <label class=\"txtright required\" for=\"appbundle_contact_lastname\">Nom</label>
        <input type=\"text\" id=\"appbundle_contact_lastname\" name=\"appbundle_contact[lastname]\" required=\"required\" class=\"\">
        <div class=\"error lastname\">

        </div>
    </div>

    <div class=\"grid-1-3\">
        <label class=\"txtright required\" for=\"appbundle_contact_firstname\">Prénom</label>
        <input type=\"text\" id=\"appbundle_contact_firstname\" name=\"appbundle_contact[firstname]\" required=\"required\" class=\"\">
        <div class=\"error firstname\">

        </div>
    </div>

    <div class=\"grid-1-3\">
        <label class=\"txtright required\" for=\"appbundle_contact_postalCode\">Code postal</label>
        <input type=\"text\" id=\"appbundle_contact_postalCode\" name=\"appbundle_contact[postalCode]\" required=\"required\" class=\"\">
        <div class=\"error postalCode\">

        </div>
    </div>

    <div class=\"grid-1-3\">
        <label class=\"txtright required\" for=\"appbundle_contact_email\">Email</label>
        <input type=\"email\" id=\"appbundle_contact_email\" name=\"appbundle_contact[email]\" required=\"required\" class=\"\">
        <div class=\"error email\">

        </div>
    </div>

    <div class=\"grid-1-3\">
        <label class=\"txtright required\" for=\"appbundle_contact_phone\">Téléphone</label>
        <input type=\"text\" id=\"appbundle_contact_phone\" name=\"appbundle_contact[phone]\" required=\"required\" class=\"\">
        <div class=\"error phone\">

        </div>
    </div>


    <p>Souhaitez-vous recevoir l'actualité immobilière et les offres personnalisées de Nexity ?</p>
    <div class=\"grid-3-1 no-label\">
        <div id=\"appbundle_contact_hasNewsletter\" class=\"grid-2 radio\"><label>
                <input type=\"radio\" id=\"appbundle_contact_hasNewsletter_0\" name=\"appbundle_contact[hasNewsletter]\" required=\"required\" value=\"1\">
                <span>oui</span>
            </label>        <label>
                <input type=\"radio\" id=\"appbundle_contact_hasNewsletter_1\" name=\"appbundle_contact[hasNewsletter]\" required=\"required\" value=\"0\">
                <span>non</span>
            </label>        </div>
    </div>


    <p>Souhaitez-vous recevoir les offres de nos partenaires ?</p>
    <div class=\"grid-3-1 no-label\">
        <div id=\"appbundle_contact_hasPartnerOffer\" class=\"grid-2 radio\"><label>
                <input type=\"radio\" id=\"appbundle_contact_hasPartnerOffer_0\" name=\"appbundle_contact[hasPartnerOffer]\" required=\"required\" value=\"1\">
                <span>oui</span>
            </label>        <label>
                <input type=\"radio\" id=\"appbundle_contact_hasPartnerOffer_1\" name=\"appbundle_contact[hasPartnerOffer]\" required=\"required\" value=\"0\">
                <span>non</span>
            </label>        </div>
    </div>


    <p class=\"form-send-ok\">
        Votre demande a bien été transférée à nos services. Nous vous remercions de l'intérêt que vous nous portez.            </p>

    <div class=\"txtcenter submit\">
        <input type=\"submit\" value=\"Valider\">
    </div>


    <div id=\"appbundle_contact\"><input type=\"hidden\" id=\"appbundle_contact__token\" name=\"appbundle_contact[_token]\" value=\"cPZ-E2PHW-Fdn99_53pSWelEbidvrVawHB08z3G1rSw\"></div>
</form>";
        
        $__internal_0de23ec9fceac02b0ebc8bdd99d450c53c125be050bb83779b1d2e3af89e7782->leave($__internal_0de23ec9fceac02b0ebc8bdd99d450c53c125be050bb83779b1d2e3af89e7782_prof);

        
        $__internal_9248644a4782dd56dfe99125b96f2c890b5e81845fe94eb376e676c51de1d143->leave($__internal_9248644a4782dd56dfe99125b96f2c890b5e81845fe94eb376e676c51de1d143_prof);

    }

    public function getTemplateName()
    {
        return "homepage/form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<form name=\"appbundle_contact\" method=\"post\" id=\"form-contact\" autocomplete=\"off\" novalidate=\"novalidate\">

    <div class=\"grid-1-3\">
        <span class=\"txtright required\">Civilité</span>
        <div id=\"appbundle_contact_civility\" class=\"grid-3 radio\"><label>
                <input type=\"radio\" id=\"appbundle_contact_civility_0\" name=\"appbundle_contact[civility]\" required=\"required\" value=\"miss\">
                <span>Mlle</span>
            </label>        <label>
                <input type=\"radio\" id=\"appbundle_contact_civility_1\" name=\"appbundle_contact[civility]\" required=\"required\" value=\"madam\">
                <span>Mme</span>
            </label>        <label>
                <input type=\"radio\" id=\"appbundle_contact_civility_2\" name=\"appbundle_contact[civility]\" required=\"required\" value=\"mister\">
                <span>M.</span>
            </label>        </div>
        <div class=\"error civility\">

        </div>
    </div>

    <div class=\"grid-1-3\">
        <label class=\"txtright required\" for=\"appbundle_contact_lastname\">Nom</label>
        <input type=\"text\" id=\"appbundle_contact_lastname\" name=\"appbundle_contact[lastname]\" required=\"required\" class=\"\">
        <div class=\"error lastname\">

        </div>
    </div>

    <div class=\"grid-1-3\">
        <label class=\"txtright required\" for=\"appbundle_contact_firstname\">Prénom</label>
        <input type=\"text\" id=\"appbundle_contact_firstname\" name=\"appbundle_contact[firstname]\" required=\"required\" class=\"\">
        <div class=\"error firstname\">

        </div>
    </div>

    <div class=\"grid-1-3\">
        <label class=\"txtright required\" for=\"appbundle_contact_postalCode\">Code postal</label>
        <input type=\"text\" id=\"appbundle_contact_postalCode\" name=\"appbundle_contact[postalCode]\" required=\"required\" class=\"\">
        <div class=\"error postalCode\">

        </div>
    </div>

    <div class=\"grid-1-3\">
        <label class=\"txtright required\" for=\"appbundle_contact_email\">Email</label>
        <input type=\"email\" id=\"appbundle_contact_email\" name=\"appbundle_contact[email]\" required=\"required\" class=\"\">
        <div class=\"error email\">

        </div>
    </div>

    <div class=\"grid-1-3\">
        <label class=\"txtright required\" for=\"appbundle_contact_phone\">Téléphone</label>
        <input type=\"text\" id=\"appbundle_contact_phone\" name=\"appbundle_contact[phone]\" required=\"required\" class=\"\">
        <div class=\"error phone\">

        </div>
    </div>


    <p>Souhaitez-vous recevoir l'actualité immobilière et les offres personnalisées de Nexity ?</p>
    <div class=\"grid-3-1 no-label\">
        <div id=\"appbundle_contact_hasNewsletter\" class=\"grid-2 radio\"><label>
                <input type=\"radio\" id=\"appbundle_contact_hasNewsletter_0\" name=\"appbundle_contact[hasNewsletter]\" required=\"required\" value=\"1\">
                <span>oui</span>
            </label>        <label>
                <input type=\"radio\" id=\"appbundle_contact_hasNewsletter_1\" name=\"appbundle_contact[hasNewsletter]\" required=\"required\" value=\"0\">
                <span>non</span>
            </label>        </div>
    </div>


    <p>Souhaitez-vous recevoir les offres de nos partenaires ?</p>
    <div class=\"grid-3-1 no-label\">
        <div id=\"appbundle_contact_hasPartnerOffer\" class=\"grid-2 radio\"><label>
                <input type=\"radio\" id=\"appbundle_contact_hasPartnerOffer_0\" name=\"appbundle_contact[hasPartnerOffer]\" required=\"required\" value=\"1\">
                <span>oui</span>
            </label>        <label>
                <input type=\"radio\" id=\"appbundle_contact_hasPartnerOffer_1\" name=\"appbundle_contact[hasPartnerOffer]\" required=\"required\" value=\"0\">
                <span>non</span>
            </label>        </div>
    </div>


    <p class=\"form-send-ok\">
        Votre demande a bien été transférée à nos services. Nous vous remercions de l'intérêt que vous nous portez.            </p>

    <div class=\"txtcenter submit\">
        <input type=\"submit\" value=\"Valider\">
    </div>


    <div id=\"appbundle_contact\"><input type=\"hidden\" id=\"appbundle_contact__token\" name=\"appbundle_contact[_token]\" value=\"cPZ-E2PHW-Fdn99_53pSWelEbidvrVawHB08z3G1rSw\"></div>
</form>", "homepage/form.html.twig", "/Applications/MAMP/htdocs/licence-test/app/Resources/views/homepage/form.html.twig");
    }
}
