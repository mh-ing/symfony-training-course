<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_c87710f357776402c9631da4bda3850b78ef8adca6273d8bd36cbe5e2fe827f2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_82fa745f5addc2a387656fd97ec0a6e9ec2aea36d500ab78630019b660f6f60a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_82fa745f5addc2a387656fd97ec0a6e9ec2aea36d500ab78630019b660f6f60a->enter($__internal_82fa745f5addc2a387656fd97ec0a6e9ec2aea36d500ab78630019b660f6f60a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_fdb761685afe10279ec3cd9b9f1950d01a49de75cb34820cd64d1eb47d62f224 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fdb761685afe10279ec3cd9b9f1950d01a49de75cb34820cd64d1eb47d62f224->enter($__internal_fdb761685afe10279ec3cd9b9f1950d01a49de75cb34820cd64d1eb47d62f224_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_82fa745f5addc2a387656fd97ec0a6e9ec2aea36d500ab78630019b660f6f60a->leave($__internal_82fa745f5addc2a387656fd97ec0a6e9ec2aea36d500ab78630019b660f6f60a_prof);

        
        $__internal_fdb761685afe10279ec3cd9b9f1950d01a49de75cb34820cd64d1eb47d62f224->leave($__internal_fdb761685afe10279ec3cd9b9f1950d01a49de75cb34820cd64d1eb47d62f224_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_f150f6da75bc56f1fe655f555ecc65c094624be5da43a262a4c7bf8c9eead8be = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f150f6da75bc56f1fe655f555ecc65c094624be5da43a262a4c7bf8c9eead8be->enter($__internal_f150f6da75bc56f1fe655f555ecc65c094624be5da43a262a4c7bf8c9eead8be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_9c3631efabfbedf43eb7255b626c5dc2b5e4f05238bdcd050dc1c6151d894117 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c3631efabfbedf43eb7255b626c5dc2b5e4f05238bdcd050dc1c6151d894117->enter($__internal_9c3631efabfbedf43eb7255b626c5dc2b5e4f05238bdcd050dc1c6151d894117_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_9c3631efabfbedf43eb7255b626c5dc2b5e4f05238bdcd050dc1c6151d894117->leave($__internal_9c3631efabfbedf43eb7255b626c5dc2b5e4f05238bdcd050dc1c6151d894117_prof);

        
        $__internal_f150f6da75bc56f1fe655f555ecc65c094624be5da43a262a4c7bf8c9eead8be->leave($__internal_f150f6da75bc56f1fe655f555ecc65c094624be5da43a262a4c7bf8c9eead8be_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_25b4ce6159d0166f9c1e597126abae6e24af530de2e1e7b6d33534a62906b499 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_25b4ce6159d0166f9c1e597126abae6e24af530de2e1e7b6d33534a62906b499->enter($__internal_25b4ce6159d0166f9c1e597126abae6e24af530de2e1e7b6d33534a62906b499_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_09e72257c21a8082a3e7e5208e917abbf521192d396aa62945bc7f7313b9f84c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09e72257c21a8082a3e7e5208e917abbf521192d396aa62945bc7f7313b9f84c->enter($__internal_09e72257c21a8082a3e7e5208e917abbf521192d396aa62945bc7f7313b9f84c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_09e72257c21a8082a3e7e5208e917abbf521192d396aa62945bc7f7313b9f84c->leave($__internal_09e72257c21a8082a3e7e5208e917abbf521192d396aa62945bc7f7313b9f84c_prof);

        
        $__internal_25b4ce6159d0166f9c1e597126abae6e24af530de2e1e7b6d33534a62906b499->leave($__internal_25b4ce6159d0166f9c1e597126abae6e24af530de2e1e7b6d33534a62906b499_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_cc6fe51cc493656ea3ea072b3dea176b7795c2f9b69c6edaf0fd25545c9115b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc6fe51cc493656ea3ea072b3dea176b7795c2f9b69c6edaf0fd25545c9115b7->enter($__internal_cc6fe51cc493656ea3ea072b3dea176b7795c2f9b69c6edaf0fd25545c9115b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_caec74744e89cdceb2f4af98ce31e1259f809bcaf5eec34533a2bbdeebbbf06e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_caec74744e89cdceb2f4af98ce31e1259f809bcaf5eec34533a2bbdeebbbf06e->enter($__internal_caec74744e89cdceb2f4af98ce31e1259f809bcaf5eec34533a2bbdeebbbf06e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_caec74744e89cdceb2f4af98ce31e1259f809bcaf5eec34533a2bbdeebbbf06e->leave($__internal_caec74744e89cdceb2f4af98ce31e1259f809bcaf5eec34533a2bbdeebbbf06e_prof);

        
        $__internal_cc6fe51cc493656ea3ea072b3dea176b7795c2f9b69c6edaf0fd25545c9115b7->leave($__internal_cc6fe51cc493656ea3ea072b3dea176b7795c2f9b69c6edaf0fd25545c9115b7_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/Applications/MAMP/htdocs/licence-test/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
